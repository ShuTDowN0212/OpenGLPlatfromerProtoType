//	Load Obj Files (Header)
//	Dept. Software Convergence, Kyung Hee University
//	Prof. Daeho Lee, nize@khu.ac.kr

bool LoadObj(char *FileName, GLfloat **Vertex, int *pVertexCnt, unsigned int **TriangleIndex, int *pTraingleCnt);